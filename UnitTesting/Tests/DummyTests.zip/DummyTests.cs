﻿using System;
using NUnit.Framework;

namespace Tests
{
    [TestFixture]
   public class DummyTests
    {
        [Test]
        public void DummyShouldLooseHealthWhenTakeAttack()
        {
            //Arrange
            Dummy dummy = new Dummy(10, 10);
            //Act
            dummy.TakeAttack(5);
            //Assert
            Assert.That(dummy.Health, Is.EqualTo(5), "Dummy didn't decrease his health corectly after take attack!");
        }
        [Test]
        public void DummyShouldThrowExceptionWhenIsDeadAnsBeenAttacked()
        {
            Dummy dummy = new Dummy(0, 10);
           
            Assert.Throws<InvalidOperationException>(() =>
            {
                dummy.TakeAttack(10);
            });
        }

        [Test]
        public void DeadDummyShouldGiveXP()
        {
            Dummy dummy = new Dummy(0, 10);
            var result = dummy.GiveExperience();
            Assert.That(result, Is.EqualTo(10));
        }

        [Test]
        public void AliveDummyShouldntGiveXP()
        {
            Dummy dummy = new Dummy(10, 10);
            Assert.Throws<InvalidOperationException>(() =>
            {
                dummy.GiveExperience();
            });
        }

    }
}
