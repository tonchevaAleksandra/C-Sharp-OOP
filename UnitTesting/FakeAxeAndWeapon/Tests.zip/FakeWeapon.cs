﻿public class FakeWeapon : IWeapon
{
    public void Attack(ITarget target)
    {
    }
}

