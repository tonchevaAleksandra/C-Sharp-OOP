﻿
namespace WildFarm.IO.Contracts
{
   public interface IReadable
    {
        string ReadLine();
    }
}
