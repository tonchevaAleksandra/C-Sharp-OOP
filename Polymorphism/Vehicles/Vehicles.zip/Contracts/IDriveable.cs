﻿
namespace Vehicles.Contracts
{
   public interface IDriveable
    {
        string Drive(double distance);
    }
}
