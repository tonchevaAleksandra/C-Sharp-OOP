﻿
namespace Vehicles.Contracts
{
   public interface IRefuelable
    {
        void Refuel(double liters);
    }
}
