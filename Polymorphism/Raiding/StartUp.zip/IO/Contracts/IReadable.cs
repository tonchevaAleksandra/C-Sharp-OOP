﻿
namespace Raiding.IO.Contracts
{
   public  interface IReadable
    {
        string ReadLine();
    }
}
