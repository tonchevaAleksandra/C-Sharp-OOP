﻿
namespace RobotService.Utilities.Enums
{
   public enum ProcedureType
    {
        Chip=1,
        Charge,
        Rest,
        Polish,
        Work,
        TechCheck
    }
}
