﻿
namespace RobotService.Utilities.Enums
{
    public enum RobotType
    {
        PetRobot=1,
        HouseholdRobot,
        WalkerRobot
    }
}
