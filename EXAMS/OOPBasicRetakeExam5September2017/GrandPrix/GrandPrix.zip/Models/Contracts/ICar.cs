﻿
public interface ICar
{
    int Hp { get; }
    double FuelAmount { get; }
    ITyre Tyre { get; }
}

