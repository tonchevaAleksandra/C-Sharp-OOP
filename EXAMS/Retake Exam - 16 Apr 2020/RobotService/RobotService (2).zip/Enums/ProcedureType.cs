﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RobotService.Enums
{
    public enum ProcedureType
    {
        Chip = 1,
        Charge,
        Rest,
        Polish,
        Work,
        TechCheck

    }
}
