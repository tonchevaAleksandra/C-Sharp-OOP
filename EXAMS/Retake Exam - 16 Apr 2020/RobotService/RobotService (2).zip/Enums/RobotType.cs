﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RobotService.Enums
{
    public enum RobotType
    {
        HouseholdRobot=1,
        WalkerRobot,
        PetRobot,

    }
}
