﻿using CounterStrike.Models.Maps.Contracts;
using CounterStrike.Models.Players;
using CounterStrike.Models.Players.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CounterStrike.Models.Maps
{
    public class Map : IMap
    {
        public string Start(ICollection<IPlayer> players)
        {
            var terrorists = players.Where(p => p.GetType().Name == nameof(Terrorist) && p.IsAlive);
            var counterTerrorists = players.Where(p => p.GetType().Name == nameof(CounterTerrorist) && p.IsAlive);


            foreach (var terrorist in terrorists)
            {
                foreach (var counterTerrorist in counterTerrorists)
                {
                    if(counterTerrorist.IsAlive)
                    {
                        counterTerrorist.TakeDamage(terrorist.Gun.Fire());
                    }
                }
            }

            foreach (var counterTerrorist in counterTerrorists.Where(c=>c.IsAlive))
            {
                foreach (var terrorist in terrorists)
                {
                    if(terrorist.IsAlive)
                    {
                        terrorist.TakeDamage(counterTerrorist.Gun.Fire());
                    }
                }
            }

            return counterTerrorists.Any(c => c.IsAlive) ? "Counter Terrorist wins!" : "Terrorist wins!";
        }
    }
}
