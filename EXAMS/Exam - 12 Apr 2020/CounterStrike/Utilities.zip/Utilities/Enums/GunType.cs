﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CounterStrike.Utilities.Enums
{
    public enum GunType
    {
        Pistol=1,
        Rifle
    }
}
