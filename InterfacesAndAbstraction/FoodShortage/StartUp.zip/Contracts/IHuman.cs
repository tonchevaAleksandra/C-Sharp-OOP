﻿namespace FoodShortage.Contracts
{
   public interface IHuman
    {
        int Age { get; }
    }
}
