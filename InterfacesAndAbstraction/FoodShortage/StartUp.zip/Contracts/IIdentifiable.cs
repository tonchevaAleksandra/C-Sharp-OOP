﻿
namespace FoodShortage.Contracts
{
   public interface IIdentifiable
    {
        string ID { get; }
    }
}
