﻿
namespace FoodShortage.Contracts
{
   public  interface IBirthdatable
    {
        string Birthdate { get; }
    }
}
