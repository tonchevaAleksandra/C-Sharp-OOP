﻿
namespace CollectionHierarchy.IO.Contracts
{
   public interface IReadable
    {
        string ReadLine();
    }
}
