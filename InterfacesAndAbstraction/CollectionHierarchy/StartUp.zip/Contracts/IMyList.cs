﻿
namespace CollectionHierarchy.Contracts
{
    public interface IMyList : IAddRemovableCollection
    {
        int Used { get; }
    }
}
