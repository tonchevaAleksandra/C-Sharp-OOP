﻿
namespace CollectionHierarchy.Contracts
{
    public interface IAddRemovableCollection : IAddCollection
    {
        string Remove();
    }
}
