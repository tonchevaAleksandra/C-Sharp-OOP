﻿
namespace BirthdayCelebrations.Models
{
    public class Pet : NaturalInhabitant
    {
        public Pet(string name, string birthdate) 
            : base(name, birthdate)
        {
        }
    }
}
