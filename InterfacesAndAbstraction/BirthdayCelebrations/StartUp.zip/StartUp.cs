﻿using System;
using BirthdayCelebrations.Core;

namespace BirthdayCelebrations
{
   public  class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
