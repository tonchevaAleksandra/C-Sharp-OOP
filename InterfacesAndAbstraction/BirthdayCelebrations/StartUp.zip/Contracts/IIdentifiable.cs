﻿
namespace BirthdayCelebrations.Contracts
{
   public interface IIdentifiable
    {
        string ID { get; }
    }
}
