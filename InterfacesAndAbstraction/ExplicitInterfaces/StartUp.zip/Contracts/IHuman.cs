﻿
namespace ExplicitInterfaces.Contracts
{
   public interface IHuman
    {
        string Name { get; }
    }
}
